# Flytrek — flights + ferries

**Flytrek** (spelled F-L-Y-T-R-E-K) is the product name. The app centers a simple journey: choose a destination, compare a flight or ferry, save a trip request, then keep its countdown and itinerary in **My trips**.

## Start locally

No dependencies or build tools are required.

```bash
cd flighttrack-app
python3 -m http.server 4173
```

Open `http://localhost:4173`. The minimal Flytrek logo screen appears on every page load; choose **Explore** to enter the app. The embedded Google map needs an internet connection; **Open map** links directly to Google Maps if the embed is blocked.

## Deploy to Vercel

1. Upload `Flytrek_Vercel.zip` at [vercel.com/drop](https://vercel.com/drop), or extract it and upload the project folder.
2. Select a team and project name, then deploy.
3. `index.html` is at the archive root. `vercel.json` pins the static output directory to `.`; there is no install or build command.

## Project handoff

Start at [`PROJECTS.md`](PROJECTS.md), then read [`docs/PROJECT_DOCUMENTATION.md`](docs/PROJECT_DOCUMENTATION.md) for screens, data model, map/payment integration notes, testing, known limitations and next steps.

## Before launch

The route catalog and fare/seat fields are indicative, not live operator inventory. **Fly now** is an availability-screen design only; no aircraft are listed as ready because no dispatch feed is connected. Round-trip requests save a return date, but only outbound listings and fares exist; the operator must confirm the return leg and fare. Checkout saves a local request only: there is no charge, operator confirmation, ticket issuance, SMS or email. The in-app Tickets tab shows tickets only when a real issued-ticket record and ticket number are present; a saved request is never a boarding pass. NIN and optional ID-photo fields are for interface review only; no OCR, upload or storage is connected. Use test details only until secure identity, operator, payment and ticket-delivery services are integrated.
