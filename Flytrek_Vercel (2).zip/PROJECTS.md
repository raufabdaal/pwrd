# Project register

Keep this index current so future contributors can quickly find the right handoff.

## Active project

### Flytrek — air + ferry booking product flow
- **Name:** Flytrek (F-L-Y-T-R-E-K), as requested.
- **Status:** Responsive multi-screen web app with a minimal Flytrek welcome screen, round-trip request capture, and an in-app Tickets tab gated on an issued ticket record; static Vercel archive rebuilt and checked.
- **Project documentation:** [`docs/PROJECT_DOCUMENTATION.md`](docs/PROJECT_DOCUMENTATION.md)
- **Quick start:** [`README.md`](README.md)
- **Screens:** Explore (one-way/round-trip date controls), outbound-only scheduled results, Fly now aircraft-feed state, Trips/Tickets tabs, digital ticket viewer, Payments, NIN/photo capture UI and local trip-request checkout.
- **Production integrations still needed:** live aircraft/dispatch availability, verified schedules/fares, secure NIN verification, payment authorization, ticket issuance, and SMS/email delivery.

## Documentation rule for future work

For each new project, add a dated entry above and create a dedicated handoff document covering purpose, status, scope, files, setup/deployment, decisions, data sources, limitations, tests and next steps. Update it after substantial changes; do not overwrite the history of another project.
