(() => {
  const departures = [
    { id: 'a8-kisoro-0700', mode: 'air', operator: 'Aerolink Uganda', service: 'Air service', origin: 'Entebbe International', originCode: 'EBB', destination: 'Kisoro', code: 'KXO', searchTerms: 'Bwindi gorillas', depart: '07:00', arrive: '08:15', duration: '1 hr 15 min', seats: 4, fare: 580000, region: 'entebbe' },
    { id: 'a8-kisoro-1030', mode: 'air', operator: 'Aerolink Uganda', service: 'Air service', origin: 'Entebbe International', originCode: 'EBB', destination: 'Kisoro', code: 'KXO', searchTerms: 'Bwindi gorillas', depart: '10:30', arrive: '11:45', duration: '1 hr 15 min', seats: 3, fare: 610000, region: 'entebbe' },
    { id: 'a8-kasese-0815', mode: 'air', operator: 'Aerolink Uganda', service: 'Air service', origin: 'Entebbe International', originCode: 'EBB', destination: 'Kasese', code: 'KSE', searchTerms: 'Queen Elizabeth Rwenzori', depart: '08:15', arrive: '09:25', duration: '1 hr 10 min', seats: 5, fare: 545000, region: 'entebbe' },
    { id: 'a8-kasese-1315', mode: 'air', operator: 'Aerolink Uganda', service: 'Air service', origin: 'Entebbe International', originCode: 'EBB', destination: 'Kasese', code: 'KSE', searchTerms: 'Queen Elizabeth Rwenzori', depart: '13:15', arrive: '14:25', duration: '1 hr 10 min', seats: 4, fare: 560000, region: 'entebbe' },
    { id: 'a8-kihihi-0745', mode: 'air', operator: 'Aerolink Uganda', service: 'Air service', origin: 'Entebbe International', originCode: 'EBB', destination: 'Kihihi', code: 'KHX', searchTerms: 'Bwindi Ishasha', depart: '07:45', arrive: '09:00', duration: '1 hr 15 min', seats: 3, fare: 570000, region: 'entebbe' },
    { id: 'a8-pakuba-0900', mode: 'air', operator: 'Aerolink Uganda', service: 'Air service', origin: 'Entebbe International', originCode: 'EBB', destination: 'Pakuba', code: 'PAF', searchTerms: 'Murchison Falls', depart: '09:00', arrive: '10:00', duration: '1 hr', seats: 6, fare: 535000, region: 'entebbe' },
    { id: 'eagle-arua-1115', mode: 'air', operator: 'Eagle Air', service: 'Air service', origin: 'Entebbe International', originCode: 'EBB', destination: 'Arua', code: 'RUA', searchTerms: 'Northern Uganda', depart: '11:15', arrive: '12:35', duration: '1 hr 20 min', seats: 7, fare: 495000, region: 'entebbe' },
    { id: 'mv-kalangala-1400', mode: 'water', operator: 'MV Kalangala', service: 'Passenger ferry', origin: 'Nakiwogo Landing Site', originCode: 'NKI', destination: 'Lutoboka, Kalangala', code: 'KAL', searchTerms: 'Ssese Islands Bugala', depart: '14:00', arrive: '17:30', duration: '3 hr 30 min', seats: 24, fare: 10000, region: 'entebbe' },
    { id: 'mv-vanessa-1300', mode: 'water', operator: 'MV Vanessa', service: 'Fast boat', origin: 'Nakiwogo Landing Site', originCode: 'NKI', destination: 'Lutoboka, Kalangala', code: 'KAL', searchTerms: 'Ssese Islands Bugala', depart: '13:00', arrive: '14:30', duration: '1 hr 30 min', seats: 8, fare: 35000, region: 'entebbe' },
    { id: 'kis-bukakata-0930', mode: 'water', operator: 'MV Pearl / MV Ssese', service: 'Vehicle & passenger ferry', origin: 'Bukakata Landing Site', originCode: 'BKT', destination: 'Bugoma Landing Site', code: 'BUG', searchTerms: 'Kalangala Bugala Island', depart: '09:30', arrive: '10:00', duration: '30 min', seats: 18, fare: 8000, region: 'bukakata' },
    { id: 'kis-bukakata-1330', mode: 'water', operator: 'MV Pearl / MV Ssese', service: 'Vehicle & passenger ferry', origin: 'Bukakata Landing Site', originCode: 'BKT', destination: 'Bugoma Landing Site', code: 'BUG', searchTerms: 'Kalangala Bugala Island', depart: '13:30', arrive: '14:00', duration: '30 min', seats: 12, fare: 8000, region: 'bukakata' }
  ];

  const places = {
    kampala: { label: 'Kampala, Uganda', map: 'Kampala, Uganda' },
    entebbe: { label: 'Entebbe, Uganda', map: 'Entebbe, Uganda' },
    bukakata: { label: 'Bukakata, Uganda', map: 'Bukakata, Masaka, Uganda' }
  };
  const payMethods = {
    mobile: [
      { id: 'mtn', title: 'MTN MoMo', description: 'Mobile money', symbol: 'MTN', className: 'mtn' },
      { id: 'airtel', title: 'Airtel Money', description: 'Mobile money', symbol: 'A', className: 'airtel' }
    ],
    card: [
      { id: 'visa', title: 'Visa', description: 'Credit or debit', symbol: 'VISA', className: 'visa' },
      { id: 'mastercard', title: 'Mastercard', description: 'Credit or debit', symbol: '●●', className: 'mastercard' }
    ]
  };

  const homeMap = document.getElementById('home-map');
  const resultsMap = document.getElementById('results-map');
  const destinationInput = document.getElementById('destination-search');
  const suggestionsBox = document.getElementById('destination-suggestions');
  const clearDestination = document.getElementById('clear-destination');
  const originSelect = document.getElementById('origin-select');
  const departDateInput = document.getElementById('depart-date');
  const returnDateInput = document.getElementById('return-date');
  const returnDateField = document.getElementById('return-date-field');
  const tripTypeButtons = document.querySelectorAll('[data-trip-type]');
  const homeSearchForm = document.getElementById('home-search-form');
  const nearbyList = document.getElementById('nearby-list');
  const resultsList = document.getElementById('results-list');
  const resultsEmpty = document.getElementById('results-empty');
  const checkoutDialog = document.getElementById('checkout-dialog');
  const checkoutContent = document.getElementById('checkout-content');
  const welcomeDialog = document.getElementById('welcome-dialog');
  const ticketDialog = document.getElementById('ticket-dialog');
  const ticketDialogContent = document.getElementById('ticket-dialog-content');
  const toast = document.getElementById('toast');

  let activeScreen = 'explore';
  let homeMode = 'all';
  let tripType = 'one-way';
  let resultsMode = 'all';
  let resultsSort = 'recommended';
  let activeResults = [];
  let selectedDepartureId = null;
  let mapPlace = '';
  let paymentPageTab = 'mobile';
  let preferredPayment = '';
  let checkoutDeparture = null;
  let checkoutStep = 1;
  let checkoutModeTab = 'mobile';
  let selectedCheckoutPayment = '';
  let checkoutTripType = 'one-way';
  let checkoutReturnDate = '';
  let tripsView = 'trips';
  let travellers = 1;
  let leadName = '';
  let leadPhone = '';
  let leadEmail = '';
  let leadNin = '';
  let idPhotoName = '';
  let toastTimer;
  let countdownTimer;

  function localDateString(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  }
  const now = new Date();
  departDateInput.min = localDateString(now);
  const defaultDate = new Date(now);
  defaultDate.setDate(defaultDate.getDate() + 1);
  departDateInput.value = localDateString(defaultDate);
  const defaultReturnDate = new Date(defaultDate);
  defaultReturnDate.setDate(defaultReturnDate.getDate() + 2);
  returnDateInput.min = localDateString(defaultDate);
  returnDateInput.value = localDateString(defaultReturnDate);
  returnDateInput.disabled = true;

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
  }
  function money(value) { return `UGX ${Number(value).toLocaleString('en-UG')}`; }
  function compactMoney(value) { return `UGX ${Math.round(Number(value) / 1000)}k`; }
  function prettyDate(value, weekday = false) {
    if (!value) return '';
    const date = new Date(`${value}T00:00:00`);
    return new Intl.DateTimeFormat('en-UG', weekday ? { weekday: 'short', day: 'numeric', month: 'short' } : { day: 'numeric', month: 'long', year: 'numeric' }).format(date);
  }
  function relativeDate(value) {
    if (!value) return '';
    const date = new Date(`${value}T00:00:00`);
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1);
    if (date.getTime() === today.getTime()) return 'Today';
    if (date.getTime() === tomorrow.getTime()) return 'Tomorrow';
    return prettyDate(value, true);
  }
  function getOffer(id) { return departures.find(item => item.id === id); }
  function readStorage(key, legacyKey) {
    try {
      let value = localStorage.getItem(key);
      if (value === null && legacyKey) {
        value = localStorage.getItem(legacyKey);
        if (value !== null) { localStorage.setItem(key, value); localStorage.removeItem(legacyKey); }
      }
      return value;
    } catch (error) { return null; }
  }
  function getOriginPlace() { return places[originSelect.value] || places.kampala; }
  function mapUrl(query, zoom = 9) { return `https://maps.google.com/maps?q=${encodeURIComponent(query)}&z=${zoom}&output=embed`; }
  function mapsLink(query) { return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`; }

  function setMapPlace(place) {
    const query = place || getOriginPlace().map;
    if (!query || query === mapPlace) return;
    mapPlace = query;
    const mapSrc = mapUrl(query, query.includes('Kampala') ? 10 : 9);
    homeMap.src = mapSrc;
    resultsMap.src = mapSrc;
    const href = mapsLink(query);
    document.getElementById('open-home-map').href = href;
    document.getElementById('open-results-map').href = href;
    document.getElementById('map-location-label').textContent = query;
  }

  function currentFilterOffers(mode, origin, query, sort = 'recommended') {
    const searchText = (query || '').trim().toLocaleLowerCase();
    let output = departures.filter(item => {
      const matchMode = mode !== 'charter' && (mode === 'all' || item.mode === mode);
      const matchOrigin = ((origin === 'kampala' || origin === 'entebbe') && item.region === 'entebbe') || (origin === 'bukakata' && item.region === 'bukakata');
      const fullText = `${item.destination} ${item.code} ${item.searchTerms} ${item.origin} ${item.operator}`.toLocaleLowerCase();
      return matchMode && matchOrigin && (!searchText || fullText.includes(searchText));
    });
    if (sort === 'price') output = output.slice().sort((a, b) => a.fare - b.fare || a.depart.localeCompare(b.depart));
    else if (sort === 'time') output = output.slice().sort((a, b) => a.depart.localeCompare(b.depart));
    else output = output.slice().sort((a, b) => a.depart.localeCompare(b.depart));
    return output;
  }

  function updateModeButtons() {
    document.querySelectorAll('[data-mode]').forEach(button => {
      const active = button.dataset.mode === homeMode;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }

  function updateTripTypeControls() {
    tripTypeButtons.forEach(button => {
      const active = button.dataset.tripType === tripType;
      const disabled = homeMode === 'charter' && button.dataset.tripType === 'round-trip';
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
      button.disabled = disabled;
    });
    const roundTrip = tripType === 'round-trip' && homeMode !== 'charter';
    returnDateField.hidden = !roundTrip;
    returnDateInput.disabled = !roundTrip;
    returnDateInput.required = roundTrip;
    homeSearchForm.classList.toggle('is-round-trip', roundTrip);
    returnDateInput.min = departDateInput.value || localDateString(now);
    if (roundTrip && returnDateInput.value && returnDateInput.value < departDateInput.value) {
      returnDateInput.value = departDateInput.value;
    }
  }

  function setTripType(type) {
    if (type === 'round-trip' && homeMode === 'charter') {
      showToast('Fly now requests do not include return legs yet.');
      return;
    }
    tripType = type === 'round-trip' ? 'round-trip' : 'one-way';
    updateTripTypeControls();
  }

  function renderNearbyCard(offer) {
    const water = offer.mode === 'water';
    const icon = water ? '#i-ferry' : '#i-plane';
    const active = selectedDepartureId === offer.id;
    return `<article class="departure-card ${active ? 'selected' : ''}" data-select-offer="${offer.id}">
      <div class="departure-card-top"><span class="departure-icon ${water ? 'water' : ''}"><svg class="icon"><use href="${icon}"/></svg></span><span class="operator-name">${escapeHtml(offer.operator)}</span></div>
      <div class="departure-title-row"><h3>${escapeHtml(offer.destination.replace(', Kalangala', ''))}</h3><strong class="departure-fare">${compactMoney(offer.fare)}</strong></div>
      <div class="departure-route">${escapeHtml(offer.origin)} → ${escapeHtml(offer.destination)}</div>
      <div class="departure-card-bottom"><span class="departure-info"><svg class="icon"><use href="#i-clock"/></svg>${escapeHtml(offer.depart)}<i></i>${escapeHtml(offer.duration)}</span><button class="card-book" type="button" data-book-offer="${offer.id}">Request <svg class="icon"><use href="#i-arrow"/></svg></button></div>
    </article>`;
  }

  function renderNearby() {
    const query = destinationInput.value.trim();
    if (homeMode === 'charter') {
      nearbyList.innerHTML = `<article class="charter-feature-card"><div class="charter-feature-top"><span class="charter-chip">FLY NOW</span><span class="charter-feed-status">Live aircraft data not connected</span></div><h3>Urgent on-demand charter</h3><p>Aircraft readiness, passenger capacity and quote must be confirmed by an operator.</p><button class="charter-feature-button" type="button" data-charter-search>Check Fly now options <svg class="icon"><use href="#i-arrow"/></svg></button></article>`;
      return;
    }
    const list = currentFilterOffers(homeMode, originSelect.value, query);
    nearbyList.innerHTML = list.map(renderNearbyCard).join('');
  }

  function renderSuggestionList() {
    const query = destinationInput.value.trim().toLocaleLowerCase();
    const unique = [...new Map(departures.map(item => [`${item.destination}-${item.mode}`, item])).values()];
    const matches = unique.filter(item => {
      const text = `${item.destination} ${item.code} ${item.searchTerms}`.toLocaleLowerCase();
      return !query || text.includes(query);
    }).slice(0, 6);
    if (!matches.length) {
      suggestionsBox.innerHTML = `<div class="suggestion-empty">No places found. Try Kisoro, Kasese or Kalangala.</div>`;
    } else {
      suggestionsBox.innerHTML = matches.map(item => `<button class="suggestion-row" type="button" role="option" data-suggestion="${escapeHtml(item.destination)}" data-map-query="${escapeHtml(item.destination + ', Uganda')}">
        <span class="suggestion-mode ${item.mode === 'water' ? 'water' : ''}"><svg class="icon"><use href="${item.mode === 'water' ? '#i-ferry' : '#i-plane'}"/></svg></span>
        <span class="suggestion-main"><strong>${escapeHtml(item.destination)}</strong><small>${item.mode === 'water' ? 'Ferry' : 'Flight'} · ${escapeHtml(item.code)}</small></span>
        <span class="suggestion-price">from ${compactMoney(item.fare)}</span>
      </button>`).join('');
    }
    suggestionsBox.hidden = false;
    destinationInput.setAttribute('aria-expanded', 'true');
  }
  function hideSuggestions() { suggestionsBox.hidden = true; destinationInput.setAttribute('aria-expanded', 'false'); }

  function renderResultCard(offer) {
    const water = offer.mode === 'water';
    const icon = water ? '#i-ferry' : '#i-plane';
    const active = selectedDepartureId === offer.id;
    return `<article class="result-card ${active ? 'is-selected' : ''}" data-select-offer="${offer.id}">
      <div class="result-card-main"><span class="result-mode-icon ${water ? 'water' : ''}"><svg class="icon"><use href="${icon}"/></svg></span><div class="result-destination"><div class="result-title-line"><h2>${escapeHtml(offer.destination)}</h2><span class="${water ? 'water' : ''}">${water ? 'Ferry' : 'Flight'}</span></div><div class="result-operator">${escapeHtml(offer.operator)} · ${escapeHtml(offer.service)}</div></div></div>
      <div class="result-route">${escapeHtml(offer.origin)} (${escapeHtml(offer.originCode)}) <span aria-hidden="true">→</span> ${escapeHtml(offer.destination)} (${escapeHtml(offer.code)})</div>
      <div class="result-details"><span><svg class="icon"><use href="#i-clock"/></svg>${escapeHtml(offer.depart)}</span><i></i><span>${escapeHtml(offer.duration)}</span><i></i><span>${offer.seats} seats</span></div>
      <div class="result-price-block"><small>per traveller</small><strong>${money(offer.fare)}</strong><button type="button" data-book-offer="${offer.id}">Request <svg class="icon"><use href="#i-arrow"/></svg></button></div>
    </article>`;
  }

  function renderResultsScreen() {
    const query = destinationInput.value.trim();
    resultsMode = homeMode;
    document.querySelectorAll('[data-results-mode]').forEach(button => {
      const active = button.dataset.resultsMode === resultsMode;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    const modeLabel = resultsMode === 'charter' ? 'Fly now' : resultsMode === 'air' ? 'Flights' : resultsMode === 'water' ? 'Ferries' : 'Trips';
    document.getElementById('results-heading').textContent = query ? `${modeLabel} to ${query}` : resultsMode === 'charter' ? 'Fly now' : `Departures near ${getOriginPlace().label.split(',')[0]}`;
    const travelDates = tripType === 'round-trip'
      ? `${prettyDate(departDateInput.value, true)} · return ${prettyDate(returnDateInput.value, true)}`
      : prettyDate(departDateInput.value, true);
    document.getElementById('results-subheading').textContent = `${travelDates} · ${getOriginPlace().label}`;
    document.querySelector('.results-data-note').textContent = resultsMode === 'charter'
      ? 'No live aircraft feed; confirm availability, readiness and price with an operator.'
      : tripType === 'round-trip'
        ? 'Outbound schedules and fares are indicative. Return timing and fare require operator confirmation.'
        : 'Times, fares & seat counts are indicative; confirm with operators.';
    document.getElementById('results-sort').value = resultsSort;
    renderResultsList();
    const mapQuery = query ? `${query}, Uganda` : getOriginPlace().map;
    mapPlace = '';
    setMapPlace(mapQuery);
  }

  function renderResultsList() {
    const query = destinationInput.value.trim();
    if (resultsMode === 'charter') {
      activeResults = [];
      document.getElementById('results-count').textContent = 'Urgent charter · operator availability required';
      resultsList.innerHTML = `<article class="charter-results-card"><div class="charter-feature-top"><span class="charter-chip">FLY NOW</span><span class="charter-feed-status">NO LIVE AIRCRAFT FEED</span></div><h2>Find an aircraft for an urgent departure</h2><p>Aircraft location, readiness, capacity and price are not connected to Flytrek yet. This list will show only operator-confirmed aircraft; none are being advertised as available here.</p><div class="charter-route-preview"><span>${escapeHtml(getOriginPlace().label)}</span><svg class="icon"><use href="#i-arrow"/></svg><strong>${escapeHtml(query || 'Choose a destination')}</strong></div><div class="charter-next-step"><svg class="icon"><use href="#i-info"/></svg>Connect participating operators’ dispatch availability before promising an on-the-spot aircraft.</div><button class="charter-edit-button" type="button" data-charter-edit>Edit trip details</button></article>`;
      resultsEmpty.hidden = true;
      resultsList.hidden = false;
      return;
    }
    activeResults = currentFilterOffers(resultsMode, originSelect.value, query, resultsSort);
    const countLabel = activeResults.length === 1 ? 'outbound option' : 'outbound options';
    document.getElementById('results-count').textContent = tripType === 'round-trip'
      ? `${activeResults.length} ${countLabel} · return ${prettyDate(returnDateInput.value, true)}`
      : `${activeResults.length} ${activeResults.length === 1 ? 'departure' : 'departures'} · ${prettyDate(departDateInput.value, true)}`;
    resultsList.innerHTML = activeResults.map(renderResultCard).join('');
    resultsEmpty.hidden = activeResults.length > 0;
    resultsList.hidden = activeResults.length === 0;
  }

  function changeScreen(screen) {
    activeScreen = screen;
    document.querySelectorAll('.app-screen').forEach(panel => { panel.hidden = panel.id !== `screen-${screen}`; });
    const nextPanel = document.getElementById(`screen-${screen}`);
    if (nextPanel) nextPanel.scrollTop = 0;
    document.querySelectorAll('[data-screen]').forEach(button => {
      const active = button.dataset.screen === screen || (screen === 'results' && button.dataset.screen === 'explore');
      button.classList.toggle('active', active);
      if (button.matches('.nav-tab, .mobile-nav-item')) button.setAttribute('aria-current', active ? 'page' : 'false');
    });
    if (screen === 'trips') renderTrips();
    if (screen === 'payments') renderPayments();
    if (screen === 'results') renderResultsScreen();
    if (screen === 'explore') { renderNearby(); setMapPlace(getOriginPlace().map); }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function openGoogleMapForOffer(offer) {
    if (!offer) return;
    const place = `${offer.destination}, Uganda`;
    mapPlace = '';
    setMapPlace(place);
  }

  function selectDeparture(id) {
    const offer = getOffer(id);
    if (!offer) return;
    selectedDepartureId = id;
    openGoogleMapForOffer(offer);
    renderNearby();
    if (activeScreen === 'results') renderResultsList();
  }

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2600);
  }

  function showCheckoutDialog() { if (!checkoutDialog.open) checkoutDialog.showModal(); }
  function clearIdentitySession() { leadName = ''; leadPhone = ''; leadEmail = ''; leadNin = ''; idPhotoName = ''; const form = document.getElementById('traveller-form'); if (form) form.reset(); }
  function closeCheckoutDialog() { if (checkoutDialog.open) checkoutDialog.close(); clearIdentitySession(); }

  function checkoutHeader(step, title, copy) {
    const labels = ['Details', 'Method'];
    const progress = `<div class="checkout-progress">${labels.map((label, index) => {
      const num = index + 1;
      const cls = num === step ? 'active' : num < step ? 'complete' : '';
      return `${index ? '<i class="progress-line"></i>' : ''}<span class="${cls}"><i class="progress-dot">${num < step ? '<svg class="icon"><use href="#i-check"/></svg>' : num}</i>${label}</span>`;
    }).join('')}</div>`;
    return `<div class="checkout-heading"><div><span>TRIP REQUEST</span><h2 id="checkout-title">${escapeHtml(title)}</h2><p>${escapeHtml(copy)}</p></div><button class="close-checkout" type="button" data-checkout-action="close" aria-label="Close booking"><svg class="icon"><use href="#i-close"/></svg></button></div>${progress}`;
  }

  function checkoutSummary(offer) {
    const water = offer.mode === 'water';
    return `<div class="checkout-trip"><div class="checkout-trip-type"><svg class="icon"><use href="${water ? '#i-ferry' : '#i-plane'}"/></svg>${water ? 'Passenger ferry' : 'Flight'} · ${escapeHtml(offer.operator)}</div>
      <div class="checkout-route"><div class="checkout-place"><strong>${escapeHtml(offer.origin)}</strong><small>${escapeHtml(offer.originCode)} · depart</small></div><span class="checkout-arrow"><svg class="icon"><use href="#i-arrow"/></svg></span><div class="checkout-place"><strong>${escapeHtml(offer.destination)}</strong><small>${escapeHtml(offer.code)} · arrive</small></div></div>
      <div class="checkout-chips"><span class="checkout-chip">${escapeHtml(prettyDate(departDateInput.value, true))}</span><span class="checkout-chip">${escapeHtml(offer.depart)} departure</span><span class="checkout-chip">${escapeHtml(offer.duration)}</span>${checkoutTripType === 'round-trip' ? `<span class="checkout-chip">Return · ${escapeHtml(prettyDate(checkoutReturnDate, true))}</span>` : ''}</div>
      ${checkoutTripType === 'round-trip' ? `<div class="return-availability-note"><svg class="icon"><use href="#i-info"/></svg><span>Return schedule and fare are not listed here. The operator must confirm the return leg; the estimate below covers the outbound leg only.</span></div>` : ''}
      <div class="checkout-total"><div class="checkout-total-item"><small>${checkoutTripType === 'round-trip' ? 'Indicative outbound fare / traveller' : 'Indicative fare / traveller'}</small><strong>${money(offer.fare)}</strong></div><div class="checkout-total-item total"><small>${checkoutTripType === 'round-trip' ? 'Outbound estimate only' : 'Estimated total'} · <span id="checkout-traveller-summary">${travellers} ${travellers === 1 ? 'traveller' : 'travellers'}</span></small><strong id="checkout-total-amount">${money(offer.fare * travellers)}</strong></div></div></div>`;
  }

  function paymentMethodButtons() {
    return payMethods[checkoutModeTab].map(method => `<button class="checkout-method ${selectedCheckoutPayment === method.id ? 'active' : ''}" type="button" data-checkout-method="${method.id}">
      <span class="method-mark ${method.className}">${method.symbol}</span><span><strong>${method.title}</strong><small>${method.description}</small></span>
    </button>`).join('');
  }

  function renderCheckout() {
    if (!checkoutDeparture) return;
    if (checkoutStep === 1) {
      checkoutContent.innerHTML = `${checkoutHeader(1, 'Traveller & ID details', 'Prepare a trip request. Nothing is sent in this version; an in-app ticket is shown only after payment and operator confirmation.')}${checkoutSummary(checkoutDeparture)}
        <form class="checkout-form" id="traveller-form">
          <div class="checkout-count-row"><span>Travellers</span><span class="count-stepper"><button type="button" data-traveller-count="minus" aria-label="Remove traveller"><svg class="icon"><use href="#i-minus"/></svg></button><strong id="traveller-count">${travellers}</strong><button type="button" data-traveller-count="plus" aria-label="Add traveller"><svg class="icon"><use href="#i-plus"/></svg></button></span></div>
          <div class="checkout-field"><label for="lead-name">Lead traveller</label><input id="lead-name" name="name" type="text" autocomplete="name" placeholder="Full name" maxlength="80" value="${escapeHtml(leadName)}" required></div>
          <div class="checkout-contact-grid"><div class="checkout-field"><label for="lead-phone">Mobile number</label><input id="lead-phone" name="phone" type="tel" autocomplete="tel" placeholder="+256 7XX XXX XXX" maxlength="24" value="${escapeHtml(leadPhone)}" required></div><div class="checkout-field"><label for="lead-email">Email address</label><input id="lead-email" name="email" type="email" autocomplete="email" placeholder="name@example.com" maxlength="120" value="${escapeHtml(leadEmail)}" required></div></div>
          <div class="checkout-field"><label for="lead-nin">NIN / National ID number</label><input id="lead-nin" name="nin" type="text" autocomplete="off" autocapitalize="characters" placeholder="Enter NIN" maxlength="24" value="${escapeHtml(leadNin)}" required></div>
          <div class="checkout-field id-photo-field"><label for="id-photo-input">National ID photo <span>(optional)</span></label><input id="id-photo-input" name="id-photo" type="file" accept="image/*" capture="environment"><small>Use camera or choose an image; enter the NIN manually (no auto-scan yet).</small><div class="id-photo-status" id="id-photo-status">${escapeHtml(idPhotoName || 'No photo selected')}</div></div>
          <div class="identity-privacy-note"><svg class="icon"><use href="#i-info"/></svg><span>This prototype does not send or save contact details, NINs or ID photos. Identity verification isn’t connected; use test details only.</span></div>
          <div class="checkout-actions"><button class="checkout-button full" type="submit">Continue to payment method <svg class="icon"><use href="#i-arrow"/></svg></button></div>
        </form>`;
    } else if (checkoutStep === 2) {
      const categories = `<div class="checkout-payment-tabs" role="tablist" aria-label="Payment type"><button class="checkout-payment-tab ${checkoutModeTab === 'mobile' ? 'active' : ''}" type="button" role="tab" aria-selected="${checkoutModeTab === 'mobile'}" data-checkout-tab="mobile">Mobile money</button><button class="checkout-payment-tab ${checkoutModeTab === 'card' ? 'active' : ''}" type="button" role="tab" aria-selected="${checkoutModeTab === 'card'}" data-checkout-tab="card">Bank card</button></div>`;
      checkoutContent.innerHTML = `${checkoutHeader(2, 'Choose a payment method', 'Choose a method to include with this request.')}${checkoutSummary(checkoutDeparture)}
        <div class="checkout-form"><div class="checkout-field"><label>PAYMENT TYPE</label>${categories}</div><div class="checkout-methods">${paymentMethodButtons()}</div>
          <div class="checkout-status-note"><svg class="icon"><use href="#i-info"/></svg><span>Indicative times/fares only. Payment is not connected, so there’s no charge or operator request. Only the itinerary is saved here; contact details, NIN and ID photo aren’t sent or stored. No card/PIN details needed.</span></div>
          <div class="checkout-actions"><button class="checkout-button secondary" type="button" data-checkout-action="back">Back</button><button class="checkout-button full" type="button" data-checkout-action="save-request">Save trip request <svg class="icon"><use href="#i-arrow"/></svg></button></div>
        </div>`;
    }
    showCheckoutDialog();
  }

  function beginCheckout(offer) {
    if (!offer) return;
    checkoutDeparture = offer;
    checkoutStep = 1;
    checkoutTripType = tripType;
    checkoutReturnDate = tripType === 'round-trip' ? returnDateInput.value : '';
    checkoutModeTab = payMethods.card.some(method => method.id === preferredPayment) ? 'card' : 'mobile';
    selectedCheckoutPayment = payMethods[checkoutModeTab].some(method => method.id === preferredPayment) ? preferredPayment : payMethods[checkoutModeTab][0].id;
    travellers = 1;
    leadName = '';
    leadPhone = '';
    leadEmail = '';
    leadNin = '';
    idPhotoName = '';
    renderCheckout();
  }

  function saveBooking(event) {
    event.preventDefault();
    const form = document.getElementById('traveller-form');
    if (!form.reportValidity()) return;
    const data = new FormData(form);
    leadName = String(data.get('name') || '').trim();
    leadPhone = String(data.get('phone') || '').trim();
    leadEmail = String(data.get('email') || '').trim();
    leadNin = String(data.get('nin') || '').trim();
    const photo = data.get('id-photo');
    if (photo && photo.size) idPhotoName = photo.name;
    checkoutStep = 2;
    if (!payMethods[checkoutModeTab].some(method => method.id === selectedCheckoutPayment)) selectedCheckoutPayment = payMethods[checkoutModeTab][0].id;
    renderCheckout();
  }

  function saveTripRequest() {
    if (!checkoutDeparture) return;
    const booking = {
      id: `FLY-RQ-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`, 
      departureId: checkoutDeparture.id,
      mode: checkoutDeparture.mode,
      operator: checkoutDeparture.operator,
      origin: checkoutDeparture.origin,
      originCode: checkoutDeparture.originCode,
      destination: checkoutDeparture.destination,
      code: checkoutDeparture.code,
      date: departDateInput.value,
      tripType: checkoutTripType,
      returnDate: checkoutTripType === 'round-trip' ? checkoutReturnDate : '',
      depart: checkoutDeparture.depart,
      arrive: checkoutDeparture.arrive,
      duration: checkoutDeparture.duration,
      travellers,
      fare: checkoutDeparture.fare,
      total: checkoutDeparture.fare * travellers,
      createdAt: new Date().toISOString()
    };
    const saved = loadBookings();
    saved.unshift(booking);
    try { localStorage.setItem('flytrek-bookings', JSON.stringify(saved.slice(0, 30))); } catch (error) { /* Keep the booking flow interactive when local storage is unavailable. */ }
    updateTripBadges();
    leadName = ''; leadPhone = ''; leadEmail = ''; leadNin = ''; idPhotoName = '';
    checkoutContent.innerHTML = `${checkoutHeader(2, 'Request saved', 'Saved in My trips on this device. No ticket has been issued yet.')}
      <div class="checkout-success"><span class="success-check"><svg class="icon"><use href="#i-check"/></svg></span><h3>Trip request saved</h3><p>No payment was taken and the operator has not confirmed availability. ${booking.tripType === 'round-trip' ? 'Your return date is saved as a request only; the operator must confirm the return schedule and fare.' : ''} An in-app digital ticket will appear in the Tickets tab once payment and operator-confirmation services are connected and the trip is confirmed. SMS delivery is not enabled yet. Local request reference:</p><span class="success-ref">${escapeHtml(booking.id)}</span></div>
      <div class="checkout-actions"><button class="checkout-button secondary" type="button" data-checkout-action="close">Close</button><button class="checkout-button full" type="button" data-checkout-action="view-trip">View My trips <svg class="icon"><use href="#i-arrow"/></svg></button></div>`;
  }

  function loadBookings() {
    try {
      const value = JSON.parse(readStorage('flytrek-bookings', 'flighttrek-bookings') || '[]');
      return Array.isArray(value) ? value : [];
    } catch (error) { return []; }
  }

  function departureMoment(booking) {
    if (!booking.date || !booking.depart) return Number.MAX_SAFE_INTEGER;
    return new Date(`${booking.date}T${booking.depart}:00+03:00`).getTime();
  }

  function ticketIssued(booking) {
    const ticket = booking && booking.ticket;
    return Boolean(ticket && ticket.status === 'issued' && String(ticket.ticketNumber || '').trim());
  }

  function ticketQrData(ticket) {
    return ticket && typeof ticket.qrDataUrl === 'string' && /^data:image\/(png|jpeg|webp);base64,/i.test(ticket.qrDataUrl) ? ticket.qrDataUrl : '';
  }

  function ticketPdfUrl(ticket) {
    return ticket && typeof ticket.pdfUrl === 'string' && (/^\/(?!\/)/.test(ticket.pdfUrl) || /^https:\/\//i.test(ticket.pdfUrl)) ? ticket.pdfUrl : '';
  }

  function renderTicketPanel(booking) {
    const ticket = booking.ticket;
    if (!ticketIssued(booking)) {
      return `<div class="ticket-pending-panel"><span class="ticket-pending-badge">NO DIGITAL TICKET YET</span><p>This saved request is not a boarding pass. An in-app ticket appears after payment and operator confirmation.</p></div>`;
    }
    const qrData = ticketQrData(ticket);
    const safePdf = ticketPdfUrl(ticket);
    return `<div class="issued-ticket-panel"><div class="issued-ticket-heading"><strong>DIGITAL TICKET</strong><span>ISSUED</span></div><div class="issued-ticket-number"><small>Ticket number</small><strong>${escapeHtml(ticket.ticketNumber)}</strong></div>${qrData ? `<img class="issued-ticket-qr" src="${escapeHtml(qrData)}" alt="Ticket QR code">` : ''}<div class="ticket-delivery-status">In-app ticket · SMS delivery is not enabled yet.</div><div class="ticket-panel-actions"><button type="button" class="ticket-show-button" data-view-ticket="${escapeHtml(booking.id)}">View ticket</button>${safePdf ? `<a class="ticket-download" href="${escapeHtml(safePdf)}" download>Download PDF</a>` : ''}</div></div>`;
  }

  function renderIssuedTicketCard(booking) {
    const icon = booking.mode === 'water' ? '#i-ferry' : '#i-plane';
    const returnLine = booking.tripType === 'round-trip' && booking.returnDate
      ? `<div class="ticket-list-return">Return requested · ${escapeHtml(prettyDate(booking.returnDate, true))}</div>`
      : '';
    return `<article class="ticket-list-card"><div class="ticket-list-heading"><span class="ticket-list-icon"><svg class="icon"><use href="${icon}"/></svg></span><span class="ticket-issued-chip">ISSUED</span></div><div class="ticket-list-route"><strong>${escapeHtml(booking.origin)}</strong><span aria-hidden="true">→</span><strong>${escapeHtml(booking.destination)}</strong></div><p>${escapeHtml(prettyDate(booking.date, true))} · ${escapeHtml(booking.depart)} · ${escapeHtml(booking.operator)}</p>${returnLine}<div class="ticket-list-footer"><span>Ticket ${escapeHtml(booking.ticket.ticketNumber)}</span><button type="button" data-view-ticket="${escapeHtml(booking.id)}">Show ticket</button></div></article>`;
  }

  function renderDigitalTicket(booking) {
    if (!ticketIssued(booking)) return '';
    const ticket = booking.ticket;
    const water = booking.mode === 'water';
    const qrData = ticketQrData(ticket);
    const safePdf = ticketPdfUrl(ticket);
    const isReturn = booking.tripType === 'round-trip' && booking.returnDate;
    const passenger = ticket.passengerName ? `<div class="digital-ticket-detail"><dt>Passenger</dt><dd>${escapeHtml(ticket.passengerName)}</dd></div>` : '';
    return `<article class="digital-ticket">
      <header class="digital-ticket-header"><div class="digital-ticket-brand"><span class="digital-ticket-mark"><svg><use href="#i-mark"/></svg></span><div><span>FLYTREK</span><h2 id="digital-ticket-title">Digital ticket</h2></div></div><span class="ticket-issued-chip">ISSUED</span></header>
      <div class="digital-ticket-number"><small>TICKET NUMBER</small><strong>${escapeHtml(ticket.ticketNumber)}</strong></div>
      <div class="digital-ticket-route"><div><small>FROM</small><strong>${escapeHtml(booking.origin)}</strong><span>${escapeHtml(booking.originCode)}</span></div><svg class="icon"><use href="#i-arrow"/></svg><div><small>TO</small><strong>${escapeHtml(booking.destination)}</strong><span>${escapeHtml(booking.code)}</span></div></div>
      <dl class="digital-ticket-details"><div class="digital-ticket-detail"><dt>Travel date</dt><dd>${escapeHtml(prettyDate(booking.date, true))}</dd></div><div class="digital-ticket-detail"><dt>Departure</dt><dd>${escapeHtml(booking.depart)}</dd></div><div class="digital-ticket-detail"><dt>Transport</dt><dd>${water ? 'Ferry' : 'Flight'}</dd></div><div class="digital-ticket-detail"><dt>Operator</dt><dd>${escapeHtml(booking.operator)}</dd></div><div class="digital-ticket-detail"><dt>Travellers</dt><dd>${booking.travellers} ${booking.travellers === 1 ? 'traveller' : 'travellers'}</dd></div>${passenger}${isReturn ? `<div class="digital-ticket-detail"><dt>Return requested</dt><dd>${escapeHtml(prettyDate(booking.returnDate, true))}</dd></div>` : ''}</dl>
      <div class="digital-ticket-code">${qrData ? `<img src="${escapeHtml(qrData)}" alt="Ticket QR code">` : `<span class="ticket-code-placeholder"><svg class="icon"><use href="#i-ticket"/></svg></span>`}<p>${qrData ? 'Show this QR code or your ticket number to the operator.' : 'Show this ticket number to the operator.'}</p></div>
      <div class="digital-ticket-note">This ticket is available in the app. SMS delivery is not enabled yet.${isReturn ? ' The return date is a request only; confirm the return leg with the operator.' : ''}</div>
      <div class="digital-ticket-actions"><button class="checkout-button secondary" type="button" data-ticket-action="close">Done</button><button class="checkout-button" type="button" data-ticket-action="print">Print ticket</button>${safePdf ? `<a class="checkout-button ticket-pdf-link" href="${escapeHtml(safePdf)}" download>Download PDF</a>` : ''}</div>
    </article>`;
  }

  function showDigitalTicket(id) {
    const booking = loadBookings().find(item => item.id === id);
    if (!ticketIssued(booking)) return;
    ticketDialogContent.innerHTML = renderDigitalTicket(booking);
    if (!ticketDialog.open) ticketDialog.showModal();
  }

  function renderTripCard(booking) {
    const icon = booking.mode === 'water' ? '#i-ferry' : '#i-plane';
    const status = ticketIssued(booking) ? 'Ticket issued' : 'Saved request';
    const returnSummary = booking.tripType === 'round-trip' && booking.returnDate
      ? `<div class="booked-trip-return"><svg class="icon"><use href="#i-calendar"/></svg>Return requested · ${escapeHtml(prettyDate(booking.returnDate, true))}<span>Operator confirmation needed</span></div>`
      : '';
    return `<article class="booked-trip-card"><div class="booked-trip-top"><span>${escapeHtml(prettyDate(booking.date, true))} · ${escapeHtml(booking.depart)}</span><b>${status}</b></div>
      <div class="booked-trip-route"><svg class="icon"><use href="${icon}"/></svg>${escapeHtml(booking.origin)} <span aria-hidden="true">→</span> ${escapeHtml(booking.destination)}</div>
      <div class="booked-trip-sub">${escapeHtml(booking.operator)} · ${booking.travellers} ${booking.travellers === 1 ? 'traveller' : 'travellers'}</div>${returnSummary}${renderTicketPanel(booking)}
      <div class="booked-trip-footer"><strong>${escapeHtml(booking.id)}</strong><button type="button" data-trip-details="${escapeHtml(booking.id)}">Trip details</button></div>
    </article>`;
  }

  function updateTripsViewTabs(ticketCount) {
    document.querySelectorAll('[data-trip-view]').forEach(button => {
      const active = button.dataset.tripView === tripsView;
      button.classList.toggle('active', active);
      button.setAttribute('aria-selected', String(active));
    });
    const panel = document.getElementById('trips-content');
    if (panel) panel.setAttribute('aria-labelledby', tripsView === 'tickets' ? 'tickets-tab' : 'trips-tab');
    const badge = document.getElementById('trip-ticket-count');
    if (badge) {
      badge.textContent = String(ticketCount);
      badge.hidden = ticketCount === 0;
    }
  }

  function renderTrips() {
    const content = document.getElementById('trips-content');
    const saved = loadBookings().sort((a, b) => departureMoment(a) - departureMoment(b));
    const tickets = saved.filter(ticketIssued).sort((a, b) => departureMoment(a) - departureMoment(b));
    const future = saved.filter(item => departureMoment(item) >= Date.now());
    const past = saved.filter(item => departureMoment(item) < Date.now());
    const tripsSubtitle = document.getElementById('trips-subtitle');
    updateTripsViewTabs(tickets.length);

    if (tripsView === 'tickets') {
      if (!tickets.length) {
        if (tripsSubtitle) tripsSubtitle.textContent = 'Digital tickets live here after payment and operator confirmation.';
        content.innerHTML = `<div class="no-tickets"><span class="no-trips-icon"><svg class="icon"><use href="#i-ticket"/></svg></span><h2>No issued tickets yet</h2><p>A saved request is not a boarding pass. An in-app ticket will appear here after payment and operator confirmation. SMS delivery is not enabled yet.</p></div>`;
        return;
      }
      if (tripsSubtitle) tripsSubtitle.textContent = 'Issued digital tickets are available to show from this screen.';
      content.innerHTML = `<div class="ticket-list">${tickets.map(renderIssuedTicketCard).join('')}</div>`;
      return;
    }

    if (tripsSubtitle) tripsSubtitle.textContent = 'Track local requests and any operator-issued digital tickets.';
    if (!saved.length) {
      content.innerHTML = `<div class="no-trips"><span class="no-trips-icon"><svg class="icon"><use href="#i-ticket"/></svg></span><h2>Your next trip will be here</h2><p>Choose a flight or ferry to save an itinerary here. Operator confirmation is still required.</p><button type="button" data-screen="explore">Explore departures</button></div>`;
      return;
    }
    const next = future[0];
    const nextCard = next ? `<article class="next-trip-card" data-countdown-target="${escapeHtml(next.date)}T${escapeHtml(next.depart)}">
      <div class="next-trip-info"><span class="up-next-label"><i></i> ${ticketIssued(next) ? 'CONFIRMED · TICKET ISSUED' : 'SAVED · NOT CONFIRMED'}</span>
        <div class="big-route"><div class="big-place"><span>FROM</span><strong>${escapeHtml(next.originCode)}</strong><small>${escapeHtml(next.origin)}</small></div><span class="big-route-arrow"><svg class="icon"><use href="#i-arrow"/></svg></span><div class="big-place"><span>TO</span><strong>${escapeHtml(next.code)}</strong><small>${escapeHtml(next.destination)}</small></div></div>
        <div class="next-trip-meta"><span><svg class="icon"><use href="#i-calendar"/></svg>${escapeHtml(prettyDate(next.date, true))}</span><span><svg class="icon"><use href="#i-clock"/></svg>${escapeHtml(next.depart)} · ${escapeHtml(next.duration)}</span>${next.tripType === 'round-trip' && next.returnDate ? `<span><svg class="icon"><use href="#i-calendar"/></svg>Return · ${escapeHtml(prettyDate(next.returnDate, true))}</span>` : ''}</div>
        ${next.tripType === 'round-trip' ? '<div class="trip-return-note">Return schedule and fare require operator confirmation.</div>' : ''}
        ${renderTicketPanel(next)}
      </div>
      <div class="countdown-side"><div class="countdown-title">Scheduled departure in</div><div class="countdown-grid"><div class="countdown-unit"><strong data-countdown="days">00</strong><span>DAYS</span></div><div class="countdown-unit"><strong data-countdown="hours">00</strong><span>HRS</span></div><div class="countdown-unit"><strong data-countdown="minutes">00</strong><span>MIN</span></div></div><div class="countdown-foot">${ticketIssued(next) ? 'Ticket' : 'Request'} ${escapeHtml(next.id)} · ${next.tripType === 'round-trip' ? 'indicative outbound estimate' : 'indicative total'} ${money(next.total)}</div></div>
    </article>` : `<div class="no-trips"><span class="no-trips-icon"><svg class="icon"><use href="#i-ticket"/></svg></span><h2>No upcoming requests</h2><p>Saved requests with past departure dates appear here.</p><button type="button" data-screen="explore">Find a trip</button></div>`;
    content.innerHTML = `${nextCard}${future.length > 1 ? `<div class="trips-list-heading"><h2>Coming up</h2><span>${future.length} trips</span></div><div class="booked-trips-grid">${future.slice(1).map(renderTripCard).join('')}</div>` : ''}${past.length ? `<div class="trips-list-heading"><h2>Past requests</h2><span>${past.length} trips</span></div><div class="booked-trips-grid">${past.map(renderTripCard).join('')}</div>` : ''}`;
    updateCountdown();
  }

    function updateCountdown() {
    const card = document.querySelector('[data-countdown-target]');
    if (!card) return;
    const value = card.dataset.countdownTarget;
    const target = new Date(`${value}:00+03:00`).getTime();
    const remaining = Math.max(0, target - Date.now());
    const days = Math.floor(remaining / 86400000);
    const hours = Math.floor((remaining % 86400000) / 3600000);
    const minutes = Math.floor((remaining % 3600000) / 60000);
    const second = Math.floor((remaining % 60000) / 1000);
    const dayEl = card.querySelector('[data-countdown="days"]');
    const hourEl = card.querySelector('[data-countdown="hours"]');
    const minuteEl = card.querySelector('[data-countdown="minutes"]');
    if (dayEl) dayEl.textContent = String(days).padStart(2, '0');
    if (hourEl) hourEl.textContent = String(hours).padStart(2, '0');
    if (minuteEl) minuteEl.textContent = String(minutes).padStart(2, '0');
    card.dataset.remainingSeconds = second;
  }

  function renderPayments() {
    document.querySelectorAll('[data-payment-tab]').forEach(button => {
      const active = button.dataset.paymentTab === paymentPageTab;
      button.classList.toggle('active', active);
      button.setAttribute('aria-selected', String(active));
    });
    const methods = payMethods[paymentPageTab];
    document.getElementById('payment-page-options').innerHTML = methods.map(method => {
      const preferred = preferredPayment === method.id;
      return `<div class="payment-choice ${preferred ? 'selected' : ''}"><span class="payment-logo ${method.className}">${method.symbol}</span><span class="payment-choice-text"><strong>${method.title}</strong><small>${method.description}</small></span>${preferred ? '<span class="preferred-tag">Preferred</span>' : `<button class="select-method" type="button" data-set-preferred="${method.id}">Set preferred</button>`}</div>`;
    }).join('');
  }

  function updateTripBadges() {
    const bookings = loadBookings();
    const count = bookings.length;
    const ticketCount = bookings.filter(ticketIssued).length;
    ['nav-trip-count', 'mobile-trip-count'].forEach(id => {
      const badge = document.getElementById(id);
      badge.textContent = count;
      badge.hidden = count === 0;
    });
    const ticketBadge = document.getElementById('trip-ticket-count');
    if (ticketBadge) {
      ticketBadge.textContent = String(ticketCount);
      ticketBadge.hidden = ticketCount === 0;
    }
  }

  function showTripDetails(id) {
    const booking = loadBookings().find(item => item.id === id);
    if (!booking) return;
    const icon = booking.mode === 'water' ? '#i-ferry' : '#i-plane';
    const statusNote = ticketIssued(booking) ? 'Digital ticket issued and available in the Tickets tab. SMS delivery is not enabled yet.' : 'Payment is not connected. Times and fares are indicative; the operator has not confirmed this request.';
    checkoutContent.innerHTML = `<div class="checkout-heading"><div><span>REQUEST DETAILS</span><h2 id="checkout-title">Trip details</h2><p>Local reference ${escapeHtml(booking.id)} · saved on this device</p></div><button class="close-checkout" type="button" data-checkout-action="close" aria-label="Close"><svg class="icon"><use href="#i-close"/></svg></button></div>
      <div class="checkout-trip"><div class="checkout-trip-type"><svg class="icon"><use href="${icon}"/></svg>${booking.mode === 'water' ? 'Passenger ferry' : 'Flight'} · ${escapeHtml(booking.operator)}</div><div class="checkout-route"><div class="checkout-place"><strong>${escapeHtml(booking.origin)}</strong><small>${escapeHtml(booking.originCode)} · depart</small></div><span class="checkout-arrow"><svg class="icon"><use href="#i-arrow"/></svg></span><div class="checkout-place"><strong>${escapeHtml(booking.destination)}</strong><small>${escapeHtml(booking.code)} · arrive</small></div></div><div class="checkout-chips"><span class="checkout-chip">${escapeHtml(prettyDate(booking.date, true))}</span><span class="checkout-chip">${escapeHtml(booking.depart)} departure</span><span class="checkout-chip">${booking.travellers} ${booking.travellers === 1 ? 'traveller' : 'travellers'}</span>${booking.tripType === 'round-trip' && booking.returnDate ? `<span class="checkout-chip">Return · ${escapeHtml(prettyDate(booking.returnDate, true))}</span>` : ''}</div>${booking.tripType === 'round-trip' ? '<div class="return-availability-note"><svg class="icon"><use href="#i-info"/></svg><span>Return timing and fare remain unconfirmed. The amount below is for the outbound leg only.</span></div>' : ''}<div class="checkout-status-note">${statusNote}</div>${renderTicketPanel(booking)}<div class="checkout-total"><div class="checkout-total-item total"><small>${booking.tripType === 'round-trip' ? 'Indicative outbound estimate' : 'Indicative total'} · ${booking.travellers} ${booking.travellers === 1 ? 'traveller' : 'travellers'}</small><strong>${money(booking.total)}</strong></div></div></div>
      <div class="checkout-actions"><button class="checkout-button secondary full" type="button" data-checkout-action="close">Close</button></div>`;
    if (!checkoutDialog.open) checkoutDialog.showModal();
  }

  // Destination search and suggestions.
  destinationInput.addEventListener('focus', renderSuggestionList);
  destinationInput.addEventListener('input', () => {
    clearDestination.hidden = !destinationInput.value;
    renderSuggestionList();
    selectedDepartureId = null;
    renderNearby();
  });
  destinationInput.addEventListener('keydown', event => {
    if (event.key === 'Escape') hideSuggestions();
    if (event.key === 'Enter' && !suggestionsBox.hidden) {
      const first = suggestionsBox.querySelector('[data-suggestion]');
      if (first) { event.preventDefault(); first.click(); }
    }
  });
  suggestionsBox.addEventListener('click', event => {
    const button = event.target.closest('[data-suggestion]');
    if (!button) return;
    destinationInput.value = button.dataset.suggestion;
    clearDestination.hidden = false;
    hideSuggestions();
    setMapPlace(button.dataset.mapQuery);
    selectedDepartureId = null;
    renderNearby();
    destinationInput.blur();
  });
  clearDestination.addEventListener('click', () => {
    destinationInput.value = '';
    clearDestination.hidden = true;
    selectedDepartureId = null;
    hideSuggestions();
    setMapPlace(getOriginPlace().map);
    renderNearby();
    destinationInput.focus();
  });
  document.addEventListener('click', event => {
    if (!suggestionsBox.hidden && !suggestionsBox.contains(event.target) && !destinationInput.contains(event.target)) hideSuggestions();
  });

  tripTypeButtons.forEach(button => button.addEventListener('click', () => setTripType(button.dataset.tripType)));
  document.querySelectorAll('[data-mode]').forEach(button => button.addEventListener('click', () => {
    const nextMode = button.dataset.mode;
    if (nextMode === 'charter') {
      if (tripType === 'round-trip') tripType = 'one-way';
      departDateInput.value = localDateString(new Date());
      departDateInput.disabled = true;
      document.getElementById('depart-field-label').textContent = 'FLY NOW';
    } else {
      if (homeMode === 'charter') departDateInput.value = localDateString(defaultDate);
      departDateInput.disabled = false;
      document.getElementById('depart-field-label').textContent = 'DEPART';
    }
    homeMode = nextMode;
    updateModeButtons();
    updateTripTypeControls();
    renderNearby();
  }));
  originSelect.addEventListener('change', () => {
    const place = getOriginPlace();
    document.getElementById('header-area-label').textContent = place.label;
    setMapPlace(place.map);
    renderNearby();
  });
  departDateInput.addEventListener('change', () => {
    updateTripTypeControls();
    if (activeScreen === 'results') renderResultsScreen();
  });
  returnDateInput.addEventListener('change', () => {
    updateTripTypeControls();
    if (activeScreen === 'results') renderResultsScreen();
  });
  homeSearchForm.addEventListener('submit', event => {
    event.preventDefault();
    if (!departDateInput.value) { departDateInput.focus(); return; }
    if (tripType === 'round-trip' && (!returnDateInput.value || returnDateInput.value < departDateInput.value)) {
      returnDateInput.reportValidity();
      return;
    }
    hideSuggestions();
    resultsMode = homeMode;
    changeScreen('results');
  });

  document.getElementById('nearby-list').addEventListener('click', event => {
    if (event.target.closest('[data-charter-search]')) {
      homeMode = 'charter';
      tripType = 'one-way';
      departDateInput.value = localDateString(new Date());
      departDateInput.disabled = true;
      document.getElementById('depart-field-label').textContent = 'FLY NOW';
      resultsMode = 'charter';
      updateModeButtons();
      updateTripTypeControls();
      changeScreen('results');
      return;
    }
    const book = event.target.closest('[data-book-offer]');
    if (book) { event.stopPropagation(); beginCheckout(getOffer(book.dataset.bookOffer)); return; }
    const card = event.target.closest('[data-select-offer]');
    if (card) selectDeparture(card.dataset.selectOffer);
  });
  document.getElementById('view-all-trips').addEventListener('click', () => { resultsMode = homeMode; changeScreen('results'); });
  document.getElementById('results-list').addEventListener('click', event => {
    if (event.target.closest('[data-charter-edit]')) { changeScreen('explore'); return; }
    const book = event.target.closest('[data-book-offer]');
    if (book) { event.stopPropagation(); beginCheckout(getOffer(book.dataset.bookOffer)); return; }
    const card = event.target.closest('[data-select-offer]');
    if (card) selectDeparture(card.dataset.selectOffer);
  });
  document.querySelectorAll('[data-results-mode]').forEach(button => button.addEventListener('click', () => {
    resultsMode = button.dataset.resultsMode;
    homeMode = resultsMode;
    if (resultsMode === 'charter' && tripType === 'round-trip') tripType = 'one-way';
    if (resultsMode === 'charter') {
      departDateInput.value = localDateString(new Date());
      departDateInput.disabled = true;
      document.getElementById('depart-field-label').textContent = 'FLY NOW';
    } else {
      if (departDateInput.disabled) departDateInput.value = localDateString(defaultDate);
      departDateInput.disabled = false;
      document.getElementById('depart-field-label').textContent = 'DEPART';
    }
    updateModeButtons();
    updateTripTypeControls();
    renderResultsScreen();
  }));
  document.getElementById('results-sort').addEventListener('change', event => { resultsSort = event.target.value; renderResultsList(); });

  // App navigation.
  document.querySelectorAll('[data-screen]').forEach(button => button.addEventListener('click', event => {
    event.preventDefault();
    changeScreen(button.dataset.screen);
  }));
  document.querySelector('[data-nav-home]').addEventListener('click', event => { event.preventDefault(); changeScreen('explore'); });

  // Checkout flow.
  checkoutDialog.addEventListener('click', event => { if (event.target === checkoutDialog) closeCheckoutDialog(); });
  checkoutDialog.addEventListener('close', clearIdentitySession);
  checkoutContent.addEventListener('submit', event => {
    if (event.target.id === 'traveller-form') saveBooking(event);
  });
  checkoutContent.addEventListener('change', event => {
    if (event.target.id === 'id-photo-input') {
      const file = event.target.files && event.target.files[0];
      idPhotoName = file ? file.name : '';
      const status = document.getElementById('id-photo-status');
      if (status) status.textContent = idPhotoName || 'No photo selected';
    }
  });
  checkoutContent.addEventListener('click', event => {
    const viewTicket = event.target.closest('[data-view-ticket]');
    if (viewTicket) { showDigitalTicket(viewTicket.dataset.viewTicket); return; }
    const close = event.target.closest('[data-checkout-action]');
    if (close) {
      const action = close.dataset.checkoutAction;
      if (action === 'close') closeCheckoutDialog();
      if (action === 'back') { checkoutStep = 1; renderCheckout(); }
      if (action === 'save-request') saveTripRequest();
      if (action === 'view-trip') { closeCheckoutDialog(); changeScreen('trips'); }
    }
    const paxButton = event.target.closest('[data-traveller-count]');
    if (paxButton && checkoutDeparture) {
      if (paxButton.dataset.travellerCount === 'plus') travellers = Math.min(checkoutDeparture.seats, travellers + 1);
      else travellers = Math.max(1, travellers - 1);
      const count = document.getElementById('traveller-count');
      if (count) count.textContent = travellers;
      const total = document.getElementById('checkout-total-amount');
      const summary = document.getElementById('checkout-traveller-summary');
      if (total) total.textContent = money(checkoutDeparture.fare * travellers);
      if (summary) summary.textContent = `${travellers} ${travellers === 1 ? 'traveller' : 'travellers'}`;
      return;
    }
    const tab = event.target.closest('[data-checkout-tab]');
    if (tab) {
      checkoutModeTab = tab.dataset.checkoutTab;
      const options = payMethods[checkoutModeTab];
      if (!options.some(method => method.id === selectedCheckoutPayment)) selectedCheckoutPayment = options[0].id;
      renderCheckout();
      return;
    }
    const method = event.target.closest('[data-checkout-method]');
    if (method) {
      selectedCheckoutPayment = method.dataset.checkoutMethod;
      checkoutContent.querySelectorAll('[data-checkout-method]').forEach(item => item.classList.toggle('active', item.dataset.checkoutMethod === selectedCheckoutPayment));
      return;
    }
  });

  // Payment preferences.
  document.querySelectorAll('[data-payment-tab]').forEach(button => button.addEventListener('click', () => {
    paymentPageTab = button.dataset.paymentTab;
    renderPayments();
  }));
  document.getElementById('payment-page-options').addEventListener('click', event => {
    const button = event.target.closest('[data-set-preferred]');
    if (!button) return;
    preferredPayment = button.dataset.setPreferred;
    try { localStorage.setItem('flytrek-preferred-payment', preferredPayment); } catch (error) { /* Preference remains active for this page. */ }
    renderPayments();
    showToast('Preferred payment method updated.');
  });

  // My trips, ticket views, and trip details.
  const tripViewTabs = [...document.querySelectorAll('[data-trip-view]')];
  tripViewTabs.forEach((button, index) => {
    button.addEventListener('click', () => {
      tripsView = button.dataset.tripView === 'tickets' ? 'tickets' : 'trips';
      renderTrips();
    });
    button.addEventListener('keydown', event => {
      let nextIndex = null;
      if (event.key === 'ArrowRight') nextIndex = (index + 1) % tripViewTabs.length;
      if (event.key === 'ArrowLeft') nextIndex = (index - 1 + tripViewTabs.length) % tripViewTabs.length;
      if (event.key === 'Home') nextIndex = 0;
      if (event.key === 'End') nextIndex = tripViewTabs.length - 1;
      if (nextIndex === null) return;
      event.preventDefault();
      tripViewTabs[nextIndex].focus();
      tripViewTabs[nextIndex].click();
    });
  });
  document.getElementById('trips-content').addEventListener('click', event => {
    const viewTicket = event.target.closest('[data-view-ticket]');
    if (viewTicket) { showDigitalTicket(viewTicket.dataset.viewTicket); return; }
    const details = event.target.closest('[data-trip-details]');
    if (details) showTripDetails(details.dataset.tripDetails);
  });
  ticketDialog.addEventListener('click', event => { if (event.target === ticketDialog) ticketDialog.close(); });
  ticketDialogContent.addEventListener('click', event => {
    const action = event.target.closest('[data-ticket-action]');
    if (!action) return;
    if (action.dataset.ticketAction === 'close') ticketDialog.close();
    if (action.dataset.ticketAction === 'print') window.print();
  });
  document.getElementById('start-exploring').addEventListener('click', () => {
    try { localStorage.setItem('flytrek-welcome-seen', 'yes'); } catch (error) { /* Continue without persistent onboarding state. */ }
    welcomeDialog.close();
  });
  welcomeDialog.addEventListener('cancel', event => { event.preventDefault(); showToast('Choose Explore to plan a journey.'); });

  preferredPayment = readStorage('flytrek-preferred-payment', 'flighttrek-preferred-payment') || '';
  if (readStorage('flytrek-welcome-seen', 'flighttrek-welcome-seen') !== 'yes') welcomeDialog.showModal();

  document.getElementById('header-area-label').textContent = getOriginPlace().label;
  setMapPlace(getOriginPlace().map);
  updateModeButtons();
  updateTripTypeControls();
  updateTripBadges();
  renderNearby();
  renderPayments();
  window.setInterval(() => { if (activeScreen === 'trips') updateCountdown(); }, 1000);
})();
