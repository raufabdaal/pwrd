# Flytrek — Project documentation

**Product name:** Flytrek (F-L-Y-T-R-E-K)  
**Product:** Scheduled flights, ferry travel, and an on-demand **Fly now** charter experience  
**Status:** Responsive frontend; live operator, identity, payment, and ticket services are not connected  
**Initial market:** Uganda  
**Updated:** 30 October 2026  

> This is the source-of-truth handoff for future work. Read it before changing the app, and update the limitations and project log after substantial changes.

## 1. Product goal and design

Help a traveller choose an air or water route, submit a trip request, and follow its indicative departure countdown in **My trips**. **Fly now** is the urgent/on-demand charter path. Do not show an aircraft as ready unless an operator confirms current location, readiness, capacity, and price.

- Keep the green, mint, and lime design direction; use a map-first, task-led Explore page.
- Keep Explore, Results, My trips, and Payments as separate views.
- Use concise cards, readable hierarchy, and clear transport icons.
- The first-run welcome uses the existing Flytrek mark, forest/mint/lime palette, and an abstract air-and-water route illustration. The illustration is decorative, not a live route map.
- A temporary, query-gated welcome layout study compares three structural directions: **Atlas** (copy first, split layout), **Editorial** (centered, single-column), and **Itinerary** (map first, split layout). Open with `?__variant=atlas`; the picker is hidden in normal customer-facing use.
- No Figma frame or external visual reference was supplied for this pass; the current logo, palette, screen structure, and product copy are the source material.
- Brand spelling is **Flytrek** (F-L-Y-T-R-E-K); the prior working name was FlightTrek.

## 2. Current screens and customer flow

### Explore

- Google Maps iframe around the selected Uganda area, with an **Open map** link.
- Destination suggestions, origin area (Kampala area / Entebbe / Bukakata), and travel-date control.
- Filters: **All**, **Flights**, **Ferries**, **Fly now**.
- Scheduled route cards show indicative operator, departure time, and fare.
- Selecting **Fly now** switches the date to today and shows an on-demand charter availability state.

### Fly now / on-demand aircraft

The charter screen is a **UI-only availability state**. It does not list fabricated aircraft, claim that an aircraft is at an airstrip, quote a charter fare, or submit a dispatch request. It explicitly says that no live aircraft feed is connected and that operator-confirmed aircraft availability is needed.

For production, the inventory feed or dispatch workflow must include aircraft base/current location, readiness/turnaround, crew status, operating hours, passenger/baggage capacity, route capability, quote, and a server-side freshness timestamp. A stale or missing listing must never appear as “ready now.”

### Search results

- Scheduled-flight and ferry results have mode filters, fare/time sorting, route details, and an indicative-data notice.
- Times, fares, and seat counts are not live; they must be verified with operators.
- The Fly now results state is separate and does not claim live inventory.
- Selecting a scheduled result updates the map query; **Request** opens checkout.

### Traveller details and checkout

- Checkout asks for lead traveller name, mobile number, email, NIN, and an optional national-ID image. The file input can open a phone camera or choose an image; the NIN is manually entered (there is no OCR/auto-scan).
- The form includes an explicit warning: identity verification is not connected, and this build does not upload or save NINs or ID photos. Use test details only.
- Mobile-money/card tabs are UI choices only. The **Save trip request** action does not charge, contact an operator, hold a seat, or confirm a trip.
- Contact details, NIN and ID-photo content are not written to localStorage or sent to a provider. The itinerary request is saved locally.

### My trips and tickets

- Locally saved requests show route details and a countdown to the indicative scheduled departure. Each request is labelled unconfirmed.
- A **Ticket pending** panel explains that an in-app ticket will appear and SMS/email delivery will follow only after payment and operator confirmation.
- The code can render an in-app e-ticket panel only when an issued `booking.ticket` object is present. No current frontend action can issue that object; no real ticket, QR, PDF, SMS, or email is generated/sent.
- Past-dated local requests are not evidence of completed travel.

### Payments

- Mobile Money and Cards tabs; a preferred method is stored locally.
- The page says payment is not connected. No card number, CVV, or mobile-money PIN is collected or stored.

## 3. Route catalog and data quality

The scheduled route catalog is hard-coded in `app.js` so the Explore and booking-request flow is populated. The interface marks schedules/fares/seats as **indicative**. This does not make the data live or verified. Confirm operators, service days, times, fares, luggage rules, and capacity before any commercial use.

### Air routes represented

- Entebbe (EBB) to Kisoro (KXO)
- Entebbe (EBB) to Kasese (KSE)
- Entebbe (EBB) to Kihihi (KHX)
- Entebbe (EBB) to Pakuba (PAF)
- Entebbe (EBB) to Arua (RUA)

Public route listings are not airline schedules or inventory feeds. FlightConnections lists Entebbe domestic connections including Kisoro, Kasese, Kihihi, and Arua ([route overview](https://www.flightconnections.com/flights-from-entebbe-ebb)). DirectFlights lists Entebbe–Kisoro departure examples and a 1h15 duration, but is not an airline inventory API ([route details](https://www.directflights.com/EBB-KXO)).

### Water routes represented

- Nakiwogo / Entebbe to Lutoboka / Kalangala (MV Kalangala and MV Vanessa)
- Bukakata to Bugoma (MV Pearl / MV Ssese)

Published visitor information lists Nakiwogo–Lutoboka route and fare/schedule details ([Mirembe Resort route information](https://www.miremberesort.co.ug/en/location)). Current reliability must be checked: a September 2026 report describes irregular MV Kalangala timings ([Daily Monitor](https://www.monitor.co.ug/uganda/news/national/passengers-complain-over-kalangala-ferry-5582742)). Public reporting also describes uncertainty around the Bukakata–Bugoma subsidy and contract ([Daily Monitor, June 2026](https://www.monitor.co.ug/uganda/news/national/kalangala-faces-ferry-uncertainty-as-free-crossing-deal-nears-expiry-5503854)).

### Data fields

Scheduled records contain `id`, `mode`, `operator`, `service`, `origin`, `originCode`, `destination`, `code`, `searchTerms`, `depart`, `arrive`, `duration`, `seats`, `fare`, and `region`. All are local UI data; `depart`, `arrive`, `duration`, `fare`, and `seats` are indicative values, not operator responses. Fly now has **no aircraft records** until an operator source is provided.

## 4. Google Maps

Explore and Results use a Google Maps iframe query (`maps.google.com/maps?q=…&output=embed`) and open-in-Maps links. Selecting an area/destination updates the query. It needs internet access and may not render inside a network-restricted preview iframe.

This best-effort iframe does not add custom Flytrek markers, a live aircraft layer, geocoding, or in-map flight routing. A production Maps Embed/JavaScript integration needs a Google Maps Platform key restricted to deployed domains and the necessary APIs; see [official Maps Embed API documentation](https://developers.google.com/maps/documentation/embed/embedding-map). Never commit an unrestricted key.

## 5. Payments, NIN privacy, and ticketing boundaries

### Current local-only behavior

The frontend has no payment processor, operator booking API, seat hold, dispatch system, identity-verification provider, ticket backend, email sender, or SMS gateway. Local request references are not booking confirmations. A ticket is not issued until the backend verifies successful payment **and** operator confirmation.

Current browser storage keys:

- `flytrek-welcome-seen` — welcome-screen preference
- `flytrek-bookings` — up to 30 itinerary/request summaries; no passenger name, contact, NIN, or photo is stored
- `flytrek-preferred-payment` — selected method preference

For continuity, the app migrates older `flighttrek-*` local preference/request keys to the new `flytrek-*` keys when present.

### NIN and ID-photo handling

- NIN is typed manually; the optional image input supports phone-camera capture/photo selection only. There is no OCR or identity verification.
- The form is frontend-only and uses in-memory field values during checkout. NIN, contact details, and ID photo are not transmitted or persisted; values are cleared when the checkout closes/completes.
- Use test values only until a secure identity workflow is implemented.
- Production must define lawful purpose/consent, minimum required data, encryption, role-based access, retention/deletion, audit trail, breach handling, and an identity verification vendor/API before accepting real NINs or ID images.

### Ticket contract for backend integration

`renderTicketPanel()` shows **Ticket pending** unless a verified issued-ticket record is available. The future app ticket renderer expects `booking.ticket.status === 'issued'`, a `ticketNumber`, optional QR image data, optional PDF URL, and SMS/email delivery status. No current client action can set a ticket to issued. Do not create a fake QR/ticket on local request save.

Recommended server-side state transition:

`request_saved → payment_authorized → operator_confirmed → ticket_issued → sms_email_delivery_status`

Issue a unique, tamper-resistant ticket only after payment and operator confirmation. Persist the authoritative ticket on the backend, show it in My trips, and send it to the verified passenger phone/email. Delivery retries and duplicate issue prevention must be handled server-side.

## 6. Technical architecture and files

Dependency-free static HTML/CSS/JS; no build step or package install.

- `index.html` — Flytrek shell, nav, Explore/Results/My trips/Payments, dialogs
- `style.css` — responsive foundation, original components, and welcome layout variants
- `design-refresh.css` — focused visual refresh for app chrome, map-led Explore, results, trips, payments, and checkout
- `app.js` — static scheduled catalog, search, Fly now no-feed state, welcome variant study, checkout/NIN/photo UI, local request summaries, ticket renderer, and countdown
- `assets/flytrek-mark.svg` — brand mark/favicon
- `vercel.json` — static/Other framework, `outputDirectory: "."`
- `README.md`, `PROJECTS.md`, `docs/PROJECT_DOCUMENTATION.md` — setup and handoff

Keep `index.html` at archive root and assets under `assets/`; do not move the app into `public/` unless the Vercel config is changed.

## 7. Run and smoke-test

From `/home/user/flighttrack-app`:

```bash
python3 -m http.server 4173
```

Open `http://localhost:4173`. Internet access is needed for Google Maps.

1. Clear `flytrek-welcome-seen`, open the welcome, and select **Explore routes**. Compare the layouts at `?__variant=atlas`, `?__variant=editorial`, and `?__variant=itinerary`; the selector should stay hidden without a valid `__variant` query.
2. Switch **All / Flights / Ferries / Fly now**. Confirm Fly now changes the departure label/date to today.
3. Open Fly now results: verify no fictitious aircraft appear and the no-live-feed state is explicit.
4. Search a scheduled route (e.g., Kisoro or Kalangala), filter/sort, and inspect the indicative-data notice.
5. Start a trip request. Verify name/mobile/email/NIN and optional photo fields appear; on mobile, the image chooser may offer camera capture. Do not use a real NIN in this frontend-only build.
6. Continue to payment and verify the copy says no charge/operator request is sent. Save the local request; confirm My trips shows unconfirmed status and **Ticket pending**—not an issued ticket.
7. Open Payments, switch tabs, set a preferred method, and refresh.
8. Test at mobile width and with network disabled; the local interface should still work if the Google map cannot load.

## 8. Vercel deployment

`Flytrek_Vercel.zip` is a static archive with `index.html` at the archive root and `outputDirectory` set to `.`. Upload through [Vercel Drop](https://vercel.com/drop); no install/build command is needed.

## 9. Production work still required

1. Provide participating charter operators, dispatch contacts, aircraft bases, and an authoritative live/confirmed availability source. Define the maximum data age and readiness criteria for “on the spot.”
2. Confirm scheduled route sources, schedules, fares, seat counts, aircraft payload/crew constraints, and any emergency/priority dispatch SLA.
3. Select an identity verification provider and retention policy for NIN/photo data; secure consent and API contracts before collecting real IDs.
4. Add a backend and payment provider, revalidate availability and pricing server-side, and implement booking idempotency and payment webhooks.
5. Implement ticket issuance only after payment authorization and operator confirmation. Add an in-app ticket/QR, secure PDF if required, SMS/email delivery and retry status.
6. Add account security, customer support, cancellations/refunds, audit logging, monitoring, and applicable local legal/data-protection review.
7. Add Google Maps keys/features only if custom markers, live aircraft position, geocoding, or routed guidance are needed.

## 10. Future-agent checklist

- Use **Flytrek** (F-L-Y-T-R-E-K); keep the requested project folder `/home/user/flighttrack-app`.
- Never present the current static route data or aircraft availability as live.
- Never represent a local request as a confirmed booking or ticket.
- Never store NIN, ID images, payment credentials, or PINs in this static bundle.
- Keep the app usable if Google Maps is blocked.
- Update this document, `PROJECTS.md`, and the project log after substantial work.

## 11. Project log

| Date | Update |
|---|---|
| 2026-10-07 | Reworked the travel prototype into separate Explore, Results, My trips/countdown, Payments, and request-checkout views with Uganda route data and Google Maps. |
| 2026-10-30 | Renamed the brand to Flytrek. Added the Fly now on-demand charter state without inventing aircraft inventory; added manual NIN and optional camera/photo UI with no upload/storage; added SMS/email contact fields, pending in-app ticket state, and an issued-ticket renderer contract for later backend integration. |
