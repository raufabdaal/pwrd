# Project register

Keep this index current so future contributors can quickly find the right handoff.

## Active project

### Flytrek — air + ferry booking product flow
- **Name:** Flytrek (F-L-Y-T-R-E-K), as requested.
- **Status:** Responsive multi-screen web app with a refreshed map-led interface and a query-gated three-layout welcome study; static Vercel bundle ready.
- **Project documentation:** [`docs/PROJECT_DOCUMENTATION.md`](docs/PROJECT_DOCUMENTATION.md)
- **Quick start:** [`README.md`](README.md)
- **Screens:** Explore, scheduled results, Fly now aircraft-feed state, My trips/countdown/ticket status, Payments, NIN/photo capture UI and trip-request checkout.
- **Production integrations still needed:** live aircraft/dispatch availability, verified schedules/fares, secure NIN verification, payment authorization, ticket issuance, and SMS/email delivery.

## Documentation rule for future work

For each new project, add a dated entry above and create a dedicated handoff document covering purpose, status, scope, files, setup/deployment, decisions, data sources, limitations, tests and next steps. Update it after substantial changes; do not overwrite the history of another project.
